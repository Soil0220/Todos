from flask import Flask, request

"""
back
"""

#class -> 사용자정의 자료형을 만드는 방법

#__name__은 현재 파일의 이름 -> Flask객체를 생성
#서버는 사용자 요청을 기다리다가 요청이 들어오면 처리해주는 프로그램이다.
#Flask웹서버는 5000번 포트로 사용자 요청을 대기한다.

app = Flask(__name__)


#decorator라고함
#자바에선 annotation이라고함
@app.route("/html")
def hello():
    """
    hello를 출력
    """
    return "hello flask"

@app.route("/hello2")
def insa():
    return "안녕하세요"

@app.route("/hello3")
def add():
    val = request.args["val"]
    # request.args라는 dictionary안에 값형태로 쿼리문의 내용을 넣는다.
    return val

app.run()